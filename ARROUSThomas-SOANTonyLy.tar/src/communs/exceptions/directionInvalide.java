package communs.exceptions;

/**
 * Class qui représente une exception si la direction donnée dans une méthode
 * n'a
 * pas de sens.
 */
public class directionInvalide extends Exception {

}
