package communs.objets;

/**
 * Enumeration permettant définir un objet avec 4 directions.
 */
public enum Direction {
    LEFT, RIGHT, UP, DOWN, ACTUEL;
}