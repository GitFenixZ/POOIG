package communs.exceptions;

/**
 * Class qui représente une exception. Si les coordonnes donner sorte d'une
 * certaine zone défini. Alors la position est invalide.
 */
public class positionInvalide extends Exception {

}
